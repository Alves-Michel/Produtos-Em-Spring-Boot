package com.estudos.produtosapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
